//! KWP2000 Protocol Message Handling
//!
//! Implements message building and parsing for ISO 14230 (KWP2000).

use tracing::debug;

/// KWP2000 message structure
#[derive(Debug, Clone)]
pub struct KwpMessage {
    pub source: u8,
    pub target: u8,
    pub data: Vec<u8>,
}

/// KWP2000 response structure
#[derive(Debug, Clone)]
pub struct KwpResponse {
    pub source: u8,
    pub target: u8,
    pub service: u8,
    pub data: Vec<u8>,
}

impl KwpMessage {
    /// Create a new KWP2000 message
    pub fn new(source: u8, target: u8, data: Vec<u8>) -> Self {
        Self { source, target, data }
    }

    /// Convert message to bytes for transmission
    ///
    /// Format: FMT TGT SRC [LEN] DATA... CHK
    ///
    /// FMT byte:
    /// - Bit 7: 1 = length in FMT byte
    /// - Bit 6: Address mode (0 = physical, 1 = functional)
    /// - Bits 5-0: Length (if bit 7 = 1)
    ///
    /// Note: KWP2000 single-frame messages support max 255 bytes of data.
    /// Longer data will be truncated with a warning.
    pub fn to_bytes(&self) -> Vec<u8> {
        let length = self.data.len();

        // KWP2000 single frame max is 255 bytes
        if length > 255 {
            debug!("WARNING: Data length {} exceeds KWP2000 max (255), truncating", length);
        }
        let effective_length = length.min(255);

        let mut bytes = Vec::with_capacity(effective_length + 5);

        if effective_length <= 63 {
            // Length in format byte
            let fmt = 0x80 | (effective_length as u8);
            bytes.push(fmt);
            bytes.push(self.target);
            bytes.push(self.source);
        } else {
            // Length in separate byte (format 0xC0 = with address, length in next byte)
            bytes.push(0xC0);
            bytes.push(self.target);
            bytes.push(self.source);
            bytes.push(effective_length as u8);
        }

        // Add data (truncate if necessary)
        bytes.extend_from_slice(&self.data[..effective_length]);

        // Calculate checksum (sum of all bytes mod 256)
        let checksum = bytes.iter().fold(0u8, |acc, &b| acc.wrapping_add(b));
        bytes.push(checksum);

        bytes
    }

    /// Create StartCommunication request (0x81)
    pub fn start_communication(source: u8, target: u8) -> Self {
        Self::new(source, target, vec![0x81])
    }

    /// Create StopCommunication request (0x82)
    pub fn stop_communication(source: u8, target: u8) -> Self {
        Self::new(source, target, vec![0x82])
    }

    /// Create TesterPresent request (0x3E)
    pub fn tester_present(source: u8, target: u8) -> Self {
        Self::new(source, target, vec![0x3E])
    }

    /// Create ReadDTCByStatus request (0x18)
    pub fn read_dtc(source: u8, target: u8, status_mask: u8) -> Self {
        Self::new(source, target, vec![0x18, 0x00, status_mask])
    }

    /// Create ClearDTC request (0x14)
    pub fn clear_dtc(source: u8, target: u8) -> Self {
        Self::new(source, target, vec![0x14, 0xFF, 0x00])
    }

    /// Create ReadDataByLocalId request (0x21)
    pub fn read_data_local(source: u8, target: u8, pid: u8) -> Self {
        Self::new(source, target, vec![0x21, pid])
    }
}

impl KwpResponse {
    /// Parse response from raw bytes
    pub fn parse(data: &[u8]) -> Option<Self> {
        if data.len() < 4 {
            debug!("Response too short: {} bytes", data.len());
            return None;
        }

        let fmt = data[0];
        let target = data[1];
        let source = data[2];

        let (data_length, data_start) = if fmt >= 0xC0 {
            // Format 0xC0-0xFF: Length in separate byte, with address
            if data.len() < 5 {
                debug!("Response too short for extended format");
                return None;
            }
            let len = data[3] as usize;
            (len, 4)
        } else if fmt >= 0x80 {
            // Format 0x80-0xBF: Length in format byte bits 0-5, with address
            let len = (fmt & 0x3F) as usize;
            (len, 3)
        } else {
            // Format 0x00-0x7F: Without address - not used in our protocol
            debug!("Unsupported format byte (no address): 0x{:02X}", fmt);
            return None;
        };

        let total_length = data_start + data_length + 1; // +1 for checksum

        if data.len() < total_length {
            debug!(
                "Response incomplete: expected {} bytes, got {}",
                total_length,
                data.len()
            );
            return None;
        }

        // Verify checksum
        let calc_checksum = data[..total_length - 1]
            .iter()
            .fold(0u8, |acc, &b| acc.wrapping_add(b));

        let recv_checksum = data[total_length - 1];

        if calc_checksum != recv_checksum {
            debug!(
                "Checksum mismatch: calculated 0x{:02X}, received 0x{:02X}",
                calc_checksum, recv_checksum
            );
            return None;
        }

        // Extract service ID and data
        let response_data = &data[data_start..data_start + data_length];

        if response_data.is_empty() {
            return None;
        }

        let service = response_data[0];
        let payload = response_data[1..].to_vec();

        Some(Self {
            source,
            target,
            service,
            data: payload,
        })
    }

    /// Check if this is a positive response
    pub fn is_positive(&self) -> bool {
        // Positive response = request service + 0x40
        self.service >= 0x40 && self.service != 0x7F
    }

    /// Check if this is a negative response
    pub fn is_negative(&self) -> bool {
        self.service == 0x7F
    }

    /// Get error code if negative response
    pub fn error_code(&self) -> Option<u8> {
        if self.is_negative() && self.data.len() >= 2 {
            Some(self.data[1])
        } else {
            None
        }
    }

    /// Get error description
    pub fn error_description(&self) -> Option<&'static str> {
        self.error_code().map(|code| match code {
            0x10 => "General reject",
            0x11 => "Service not supported",
            0x12 => "Sub-function not supported",
            0x13 => "Message length incorrect",
            0x14 => "Response too long",
            0x21 => "Busy - repeat request",
            0x22 => "Conditions not correct",
            0x23 => "Routine not complete",
            0x24 => "Request sequence error",
            0x25 => "No response from subnet",
            0x26 => "Failure prevents execution",
            0x31 => "Request out of range",
            0x33 => "Security access denied",
            0x35 => "Invalid key",
            0x36 => "Exceed number of attempts",
            0x37 => "Required time delay not expired",
            0x40 => "Download not accepted",
            0x41 => "Improper download type",
            0x42 => "Can not download to specified address",
            0x43 => "Can not download number of bytes requested",
            0x50 => "Upload not accepted",
            0x51 => "Improper upload type",
            0x52 => "Can not upload from specified address",
            0x53 => "Can not upload number of bytes requested",
            0x71 => "Transfer suspended",
            0x72 => "Transfer aborted",
            0x74 => "Illegal address in block transfer",
            0x75 => "Illegal byte count in block transfer",
            0x76 => "Illegal block transfer type",
            0x77 => "Block transfer data checksum error",
            0x78 => "Request correctly received, response pending",
            0x79 => "Incorrect byte count during block transfer",
            0x80 => "Service not supported in active diagnostic session",
            _ => "Unknown error",
        })
    }
}

/// KWP2000 Service IDs
#[allow(dead_code)]
pub mod services {
    // Diagnostic Management
    pub const START_DIAGNOSTIC_SESSION: u8 = 0x10;
    pub const ECU_RESET: u8 = 0x11;
    pub const CLEAR_DIAGNOSTIC_INFO: u8 = 0x14;
    pub const READ_DTC_BY_STATUS: u8 = 0x18;
    pub const READ_DTC_BY_NUMBER: u8 = 0x19;
    pub const READ_ECU_IDENTIFICATION: u8 = 0x1A;
    pub const STOP_DIAGNOSTIC_SESSION: u8 = 0x20;
    pub const READ_DATA_BY_LOCAL_ID: u8 = 0x21;
    pub const READ_DATA_BY_COMMON_ID: u8 = 0x22;
    pub const READ_MEMORY_BY_ADDRESS: u8 = 0x23;
    pub const SECURITY_ACCESS: u8 = 0x27;
    pub const DISABLE_NORMAL_MESSAGE_TX: u8 = 0x28;
    pub const ENABLE_NORMAL_MESSAGE_TX: u8 = 0x29;
    pub const DYNAMICALLY_DEFINE_LOCAL_ID: u8 = 0x2C;
    pub const WRITE_DATA_BY_COMMON_ID: u8 = 0x2E;
    pub const INPUT_OUTPUT_CONTROL: u8 = 0x30;
    pub const START_ROUTINE_BY_LOCAL_ID: u8 = 0x31;
    pub const STOP_ROUTINE_BY_LOCAL_ID: u8 = 0x32;
    pub const REQUEST_ROUTINE_RESULTS: u8 = 0x33;
    pub const REQUEST_DOWNLOAD: u8 = 0x34;
    pub const REQUEST_UPLOAD: u8 = 0x35;
    pub const TRANSFER_DATA: u8 = 0x36;
    pub const REQUEST_TRANSFER_EXIT: u8 = 0x37;
    pub const WRITE_DATA_BY_LOCAL_ID: u8 = 0x3B;
    pub const WRITE_MEMORY_BY_ADDRESS: u8 = 0x3D;
    pub const TESTER_PRESENT: u8 = 0x3E;

    // Communication Control
    pub const START_COMMUNICATION: u8 = 0x81;
    pub const STOP_COMMUNICATION: u8 = 0x82;
    pub const ACCESS_TIMING_PARAMETERS: u8 = 0x83;

    // Negative Response
    pub const NEGATIVE_RESPONSE: u8 = 0x7F;
}

/// Common PIDs for BMW
#[allow(dead_code)]
pub mod pids {
    pub const ENGINE_RPM: u8 = 0x0C;
    pub const COOLANT_TEMP: u8 = 0x05;
    pub const VEHICLE_SPEED: u8 = 0x0D;
    pub const THROTTLE_POSITION: u8 = 0x11;
    pub const ENGINE_LOAD: u8 = 0x04;
    pub const INTAKE_AIR_TEMP: u8 = 0x0F;
    pub const MAF_SENSOR: u8 = 0x10;
    pub const FUEL_PRESSURE: u8 = 0x0A;
    pub const INTAKE_MANIFOLD_PRESSURE: u8 = 0x0B;
    pub const TIMING_ADVANCE: u8 = 0x0E;
    pub const O2_SENSOR_BANK1_SENSOR1: u8 = 0x14;
    pub const O2_SENSOR_BANK1_SENSOR2: u8 = 0x15;
    pub const FUEL_SYSTEM_STATUS: u8 = 0x03;
    pub const BATTERY_VOLTAGE: u8 = 0x42;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_message_building() {
        let msg = KwpMessage::new(0xF1, 0x12, vec![0x3E]);
        let bytes = msg.to_bytes();

        // Expected: 81 12 F1 3E CS
        assert_eq!(bytes.len(), 5);
        assert_eq!(bytes[0], 0x81); // FMT: 0x80 | 1
        assert_eq!(bytes[1], 0x12); // Target
        assert_eq!(bytes[2], 0xF1); // Source
        assert_eq!(bytes[3], 0x3E); // Service

        // Checksum
        let expected_checksum = (0x81 + 0x12 + 0xF1 + 0x3E) & 0xFF;
        assert_eq!(bytes[4], expected_checksum as u8);
    }

    #[test]
    fn test_response_parsing() {
        // Example positive response to TesterPresent
        let data = vec![0x81, 0xF1, 0x12, 0x7E, 0x22]; // FMT TGT SRC SVC CHK

        let response = KwpResponse::parse(&data).unwrap();

        assert_eq!(response.source, 0x12);
        assert_eq!(response.target, 0xF1);
        assert_eq!(response.service, 0x7E);
        assert!(response.is_positive());
    }
}
